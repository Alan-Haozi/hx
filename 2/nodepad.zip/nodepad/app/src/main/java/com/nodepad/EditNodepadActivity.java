package com.nodepad;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.nodepad.data.Things;
import com.nodepad.utils.DBOpenHelper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

//编辑日记
public class EditNodepadActivity extends AppCompatActivity implements View.OnClickListener {

    //声明控件
    private TextView tv_author;
    private TextView tv_createtime;
    private EditText titleTxt;
    private EditText contentTxt;
    private ImageView iv_imgs;
    private DBOpenHelper dbOpenHelper;
    private String filepath="";
    private File fileDir;
    //打开相册的请求码
    public static final  int GALLERY_REQUEST_CODE = 0x01;
    //打开摄像头的请求码
    private static final int CAMERA_REQUEST_CODE = 0x02;
    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_nodepad);
        dbOpenHelper = new DBOpenHelper(this);

        ActionBar actionBar = getActionBar();
        if(actionBar!=null){
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_back);
        }
        initView();
        //接收参数
        id=getIntent().getStringExtra("id");
        Things data = dbOpenHelper.getNodepad(Integer.parseInt(id));
        tv_author.setText("作者："+data.getAuthor());
        tv_createtime.setText("创建时间："+data.getCreatetime());
        titleTxt.setText(data.getTitle());
        contentTxt.setText(data.getContent());
        if(!data.getFilepath().equals("")){
            Glide.with(this).load(data.getFilepath()).into(iv_imgs);
        }
    }

    //控件和布局文件里的绑定
    private void initView() {
        tv_author = findViewById(R.id.tv_author);
        tv_createtime = findViewById(R.id.tv_createtime);
        titleTxt = (EditText)findViewById(R.id.title);
        contentTxt = (EditText)findViewById(R.id.content);
        iv_imgs = findViewById(R.id.iv_imgs);
        findViewById(R.id.uploadFileBtn).setOnClickListener(this);
        findViewById(R.id.submitBtn).setOnClickListener(this);
    }

    //按钮点击事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.uploadFileBtn:
                requestCameraPermission();
                break;
            case R.id.submitBtn:
                //获取控件的值
                String title = titleTxt.getText().toString();
                String content = contentTxt.getText().toString();
                //判断是否为空
                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(content)) {
                    //提交到数据库
                    boolean flag=dbOpenHelper.updateNodepad(id,title,content,filepath);
                    if(flag){
                        //跳回到事项列表
                        Toast.makeText(EditNodepadActivity.this, "修改成功!", Toast.LENGTH_SHORT).show();
                        finish();
                    }else{
                        //弹出提示信息
                        Toast.makeText(EditNodepadActivity.this, "修改失败!", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(EditNodepadActivity.this, "标题和内容不能为空！", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * 当用户点击打开摄像头拍照时，请求获得使用摄像头权限和读写SD卡权限
     */
    private void requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[] {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
        }else{
            showPopueWindow();
        }
    }

    /**
     * 当用户选择是否授予权限后回调此方法
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == 1000) {
            if (grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showPopueWindow();
            } else {
                Toast.makeText(EditNodepadActivity.this, "请授予使用相机和读写外部存储器的权限", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //弹出图片选择框
    private void showPopueWindow(){
        View popView = View.inflate(this,R.layout.popupwindow_camera_need,null);
        Button bt_album = (Button) popView.findViewById(R.id.btn_pop_album);
        Button bt_camera = (Button) popView.findViewById(R.id.btn_pop_camera);
        Button bt_cancle = (Button) popView.findViewById(R.id.btn_pop_cancel);
        int weight = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels*1/3;

        final PopupWindow popupWindow = new PopupWindow(popView,weight,height);
        popupWindow.setAnimationStyle(android.R.style.Animation_InputMethod);
        popupWindow.setFocusable(true);
        popupWindow.setOutsideTouchable(true);

        //点击相册按钮
        bt_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(i, GALLERY_REQUEST_CODE);
                popupWindow.dismiss();

            }
        });
        //点击拍照按钮
        bt_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");

                fileDir = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + "photo");
                if(!fileDir.exists()) {
                    fileDir.mkdir();
                }

                long currentTimeMillis = System.currentTimeMillis();
                Date today = new Date(currentTimeMillis);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
                String title = dateFormat.format(today);
                filepath = fileDir + File.separator + title+".jpg";

                File cameraSavePath = new File(filepath);

                //如果版本大于安卓7.0
                Uri imageUri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    imageUri = FileProvider.getUriForFile(EditNodepadActivity.this, "com.nodepad.fileprovider", cameraSavePath);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } else {
                    imageUri = Uri.fromFile(cameraSavePath);
                }
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, CAMERA_REQUEST_CODE);
                popupWindow.dismiss();
            }
        });
        //点击取消按钮
        bt_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.alpha = 1.0f;
                getWindow().setAttributes(lp);
            }
        });
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.5f;
        getWindow().setAttributes(lp);
        popupWindow.showAtLocation(popView, Gravity.BOTTOM,0,50);
    }

    // 获取文件的真实路径
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        fileDir = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + "photo");
        if(!fileDir.exists()) {
            fileDir.mkdir();
        }
        //如果从图库界面返回
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            //如果用户选择了相片
            if(data != null) {
                Uri selectedImage = data.getData();
                String[] filePathColumn = { MediaStore.Images.Media.DATA };
                //查询我们需要的数据
                Cursor cursor = getContentResolver().query(selectedImage,
                        filePathColumn, null, null, null);
                cursor.moveToFirst();
                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                String picturePath = cursor.getString(columnIndex);
                cursor.close();

                filepath = picturePath;
                postMessageToServer(picturePath);
            }
        }

        //如果从摄像头界面返回
        if(requestCode == CAMERA_REQUEST_CODE) {
            //如果用户拍摄了相片
            try {
                postMessageToServer(filepath);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void postMessageToServer(String imgpath) {
        // TODO 调用接口
        Glide.with(this).load(imgpath).into(iv_imgs);
    }
}