package com.nodepad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.nodepad.adapter.ViewPagerAdapter;
import com.nodepad.fragment.AuthorFragment;
import com.nodepad.fragment.NodepadFragment;

import java.util.ArrayList;
import java.util.List;

//主页
public class MainActivity extends AppCompatActivity {

    private ViewPager vp;
    private TabLayout mTabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vp = findViewById(R.id.view_pager);
        mTabLayout = findViewById(R.id.tab_layout);
        List<String> mTitles = new ArrayList<>();
        mTitles.add("日记");
        mTitles.add("作者");

        List<Fragment> mFragments = new ArrayList<>();
        mFragments.add(new NodepadFragment());
        mFragments.add(new AuthorFragment());
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager(), mFragments, mTitles);
        vp.setAdapter(adapter);
        mTabLayout.setupWithViewPager(vp);
    }
}