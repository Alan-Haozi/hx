package com.nodepad.fragment;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.nodepad.R;

/**
 * 设置作者
 */
public class AuthorFragment extends Fragment {

    private EditText et_author;

    public AuthorFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_author, container, false);
        et_author = view.findViewById(R.id.et_name);
        SharedPreferences sp = getActivity().getSharedPreferences("authorinfo", 0);
        String userName = sp.getString("author","游客");
        et_author.setText(userName);
        Button saveBtn = view.findViewById(R.id.bt_save);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String author = et_author.getText().toString();
                if(author.equals("")){
                    Toast.makeText(getActivity(),"作者姓名不能为空",Toast.LENGTH_SHORT).show();
                }else{
                    //存储作者姓名
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("author",author);
                    editor.commit();
                    Toast.makeText(getActivity(), "保存成功!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }
}