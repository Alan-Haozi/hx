package com.nodepad.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.nodepad.AddNodepadActivity;
import com.nodepad.EditNodepadActivity;
import com.nodepad.R;
import com.nodepad.adapter.ThingsAdapter;
import com.nodepad.data.Things;
import com.nodepad.utils.DBOpenHelper;

import java.util.List;

/**
 * 日记列表页面
 */
public class NodepadFragment extends Fragment implements View.OnClickListener,ThingsAdapter.InnerItemOnclickListener{

    private DBOpenHelper dbOpenHelper;
    private ListView listView;
    private List<Things> list;
    private ThingsAdapter adapter;
    private boolean isGetData = false;
    private String author="";

    public NodepadFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_nodepad, container, false);
        dbOpenHelper = new DBOpenHelper(getActivity());
        //获取作者
        SharedPreferences sp = getActivity().getSharedPreferences("authorinfo", 0);
        author = sp.getString("author","游客");
        //从数据库里获取数据
        list = dbOpenHelper.getNodepads(author);
        //控件和布局文件里的绑定
        adapter = new ThingsAdapter(getActivity(), list);
        adapter.setOnInnerItemOnClickListener(this);
        listView = (ListView) view.findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        TextView addTxt = (TextView) view.findViewById(R.id.addBtn);
        addTxt.setOnClickListener(this);

        return view;
    }

    //响应点击事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addBtn:
                //跳转到添加页面
                isGetData = true;
                Intent intent = new Intent(getActivity(), AddNodepadActivity.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    public Animation onCreateAnimation(int transit, boolean enter, int nextAnim) {
        //   进入当前Fragment
        if (enter && !isGetData) {
            isGetData = true;
            GetData();
        } else {
            isGetData = false;
        }
        return super.onCreateAnimation(transit, enter, nextAnim);
    }

    @Override
    public void onPause() {
        super.onPause();
        isGetData = false;
    }

    @Override
    public void onResume() {
        if (!isGetData) {
            GetData();
            isGetData = true;
        }
        super.onResume();
    }

    private void GetData() {
        list.clear();
        List<Things> templist = dbOpenHelper.getNodepads(author);
        for(int i=0;i<templist.size();i++){
            list.add(templist.get(i));
        }
        adapter.notifyDataSetChanged();
    }

    //响应点击事件
    @Override
    public void itemClick(View v) {
        int position;
        position = (Integer) v.getTag();
        switch (v.getId()) {
            case R.id.editbtn:
                isGetData = true;
                Intent intent=new Intent(getActivity(), EditNodepadActivity.class);
                intent.putExtra("id", list.get(position).getId()+"");
                intent.putExtra("title", list.get(position).getTitle());
                intent.putExtra("detail", list.get(position).getContent());
                intent.putExtra("filepath", list.get(position).getFilepath());
                startActivity(intent);
                break;
            case R.id.delbtn:
                //删除数据库里的数据
                boolean flag = dbOpenHelper.delNodepad(list.get(position).getId());
                if(flag){
                    //变更数据源
                    list.remove(position);
                    //通知适配器变更
                    adapter.notifyDataSetChanged();
                    //弹出提示信息
                    Toast.makeText(getActivity(),"删除成功",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getActivity(),"删除失败",Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                break;
        }
    }
}