package com.nodepad.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import android.view.View.OnClickListener;

import com.nodepad.R;
import com.nodepad.data.Things;

public class ThingsAdapter  extends BaseAdapter implements OnClickListener{
    private Context context;
    private List<Things> list = new ArrayList<Things>();
    private InnerItemOnclickListener mListener;

    public ThingsAdapter(Context context, List<Things> objects) {
        super();
        this.context = context;
        this.list=objects;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return list == null?0:list.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.list_item, null);
        Things t = (Things) getItem(position);

        TextView title = (TextView) view.findViewById(R.id.t_title);
        title.setText(t.getTitle());
        TextView dtitle = (TextView) view.findViewById(R.id.t_dtitle);
        dtitle.setText(t.getContent());

        TextView editbtn = (TextView)view.findViewById(R.id.editbtn);
        editbtn.setTag(position);
        editbtn.setOnClickListener(this);

        TextView delbtn =(TextView) view.findViewById(R.id.delbtn);
        delbtn.setTag(position);
        delbtn.setOnClickListener(this);
        return view;
    }

    public interface InnerItemOnclickListener {
        void itemClick(View v);
    }

    public void setOnInnerItemOnClickListener(InnerItemOnclickListener listener){
        this.mListener=listener;
    }

    @Override
    public void onClick(View v) {
        mListener.itemClick(v);
    }
}
