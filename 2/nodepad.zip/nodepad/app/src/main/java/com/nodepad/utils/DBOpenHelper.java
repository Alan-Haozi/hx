package com.nodepad.utils;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.nodepad.data.Things;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//数据库操作类
public class DBOpenHelper extends SQLiteOpenHelper{
    /**
     * 声明一个AndroidSDK自带的数据库变量db
     */
    private SQLiteDatabase db;

    /**
     * 写一个这个类的构造函数，参数为上下文context，所谓上下文就是这个类所在包的路径
     */
    public DBOpenHelper(Context context){
        super(context,"db_test",null,1);
        db = getReadableDatabase();
    }

    /**
     * 重写两个必须要重写的方法，因为class DBOpenHelper extends SQLiteOpenHelper
     * 而这两个方法是 abstract 类 SQLiteOpenHelper 中声明的 abstract 方法
     * 所以必须在子类 DBOpenHelper 中重写 abstract 方法
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db){
        //日记表
        db.execSQL("CREATE TABLE IF NOT EXISTS nodepads(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT," +
                "content TEXT," +
                "author TEXT," +
                "filepath TEXT," +
                "createtime TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        onCreate(db);
    }

    //获取所有个人日记
    @SuppressLint("Range")
    public List<Things> getNodepads(String author){
        List<Things> list = new ArrayList<Things>();
        Cursor cursor = db.query("nodepads",null,"author='"+author+"'",null,null,null,null);
        while (cursor.moveToNext()){
            Things data=new Things();
            data.setId(cursor.getInt(cursor.getColumnIndex("_id")));
            data.setTitle(cursor.getString(cursor.getColumnIndex("title")));
            data.setContent(cursor.getString(cursor.getColumnIndex("content")));
            data.setAuthor(cursor.getString(cursor.getColumnIndex("author")));
            data.setFilepath(cursor.getString(cursor.getColumnIndex("filepath")));
            data.setCreatetime(cursor.getString(cursor.getColumnIndex("createtime")));
            list.add(data);
        }
        return list;
    }

    //添加日记
    public boolean addNodepad(String title,String content,String author,String filepath){
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);
        values.put("author", author);
        values.put("filepath", filepath);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date curDate = new Date(System.currentTimeMillis());
        values.put("createtime",formatter.format(curDate));
        return db.insert("nodepads", null, values) > 0;
    }

    //删除日记
    public boolean delNodepad(int id){
        return db.delete("nodepads","_id=?",new String[]{id+""})>0;
    }

    //更新日记
    public boolean updateNodepad(String id,String title,String content,String filepath) {
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);
        values.put("filepath", filepath);
        return db.update("nodepads",values,"_id=?",new String[]{id}) > 0;
    }

    //获取指定日记
    @SuppressLint("Range")
    public Things getNodepad(int id){
        Things data = null;
        Cursor cursor = db.query("nodepads",null,"_id="+id,null,null,null,null);
        while (cursor.moveToNext()) {
            data = new Things();
            data.setId(cursor.getInt(cursor.getColumnIndex("_id")));
            data.setTitle(cursor.getString(cursor.getColumnIndex("title")));
            data.setContent(cursor.getString(cursor.getColumnIndex("content")));
            data.setAuthor(cursor.getString(cursor.getColumnIndex("author")));
            data.setFilepath(cursor.getString(cursor.getColumnIndex("filepath")));
            data.setCreatetime(cursor.getString(cursor.getColumnIndex("createtime")));
        }
        return data;
    }
}
