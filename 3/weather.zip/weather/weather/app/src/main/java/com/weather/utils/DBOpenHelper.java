package com.weather.utils;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.weather.data.Weather;

import java.util.ArrayList;
import java.util.List;

public class DBOpenHelper extends SQLiteOpenHelper {
    /**
     * 声明一个AndroidSDK自带的数据库变量db
     */
    private SQLiteDatabase db;

    /**
     * 写一个这个类的构造函数，参数为上下文context，所谓上下文就是这个类所在包的路径
     */
    public DBOpenHelper(Context context){
        super(context,"db_test",null,1);
        db = getReadableDatabase();
    }

    /**
     * 重写两个必须要重写的方法，因为class DBOpenHelper extends SQLiteOpenHelper
     * 而这两个方法是 abstract 类 SQLiteOpenHelper 中声明的 abstract 方法
     * 所以必须在子类 DBOpenHelper 中重写 abstract 方法
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS weathers(" +
                "cityid TEXT," +
                "cityname TEXT," +
                "jsondata TEXT," +
                "isattention TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        onCreate(db);
    }

    public boolean addWeather(String cityid,String cityname,String json){
        ContentValues values = new ContentValues();
        values.put("cityid",cityid);
        values.put("cityname",cityname);
        values.put("jsondata",json);
        values.put("isattention","n");
        return db.insert("weathers", null, values) > 0;
    }

    @SuppressLint("Range")
    public Weather getWeather(String cityid){
        Weather data = null;
        Cursor cursor = db.query("weathers",null,"cityid='"+cityid+"'",null,null,null,null);
        if(cursor.moveToNext()) {
            data = new Weather();
            data.setCityid(cursor.getString(cursor.getColumnIndex("cityid")));
            data.setCityname(cursor.getString(cursor.getColumnIndex("cityname")));
            data.setJsondata(cursor.getString(cursor.getColumnIndex("jsondata")));
            data.setIsattention(cursor.getString(cursor.getColumnIndex("isattention")));
        }
        return data;
    }

    public boolean updateAttention(String cityid){
        ContentValues values = new ContentValues();
        values.put("isattention","y");
        return db.update("weathers",values,"cityid=?",new String[]{cityid}) > 0;
    }

    @SuppressLint("Range")
    public List<Weather> getAttentionWeather(){
        List<Weather> list = new ArrayList<>();
        Cursor cursor = db.query("weathers",null,"isattention='y'",null,null,null,null);
        while(cursor.moveToNext()){
            Weather data = new Weather();
            data.setCityid(cursor.getString(cursor.getColumnIndex("cityid")));
            data.setCityname(cursor.getString(cursor.getColumnIndex("cityname")));
            data.setJsondata(cursor.getString(cursor.getColumnIndex("jsondata")));
            data.setIsattention(cursor.getString(cursor.getColumnIndex("isattention")));
            list.add(data);
        }

        return list;
    }
}
