package com.weather.data;

public class WeatherBean {
    private String city;
    private String cityId;
    private String week;
    private String temp;
    private String date_y;
    private String wind;
    private String weather;
    private String pm;
    private String tempCurrent;
    private String windCurrent;
    private String updatetime;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getDate_y() {
        return date_y;
    }

    public void setDate_y(String date_y) {
        this.date_y = date_y;
    }

    public String getWind() {
        return wind;
    }

    public void setWind(String wind) {
        this.wind = wind;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public String getPm() {
        return pm;
    }

    public void setPm(String pm) {
        this.pm = pm;
    }

    public String getTempCurrent() {
        return tempCurrent;
    }

    public void setTempCurrent(String tempCurrent) {
        this.tempCurrent = tempCurrent;
    }

    public String getWindCurrent() {
        return windCurrent;
    }

    public void setWindCurrent(String windCurrent) {
        this.windCurrent = windCurrent;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }
}

