package com.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.weather.data.Weather;
import com.weather.utils.DBOpenHelper;
import com.zaaach.citypicker.CityPicker;
import com.zaaach.citypicker.adapter.OnPickListener;
import com.zaaach.citypicker.model.City;
import com.zaaach.citypicker.model.HotCity;

import java.util.ArrayList;
import java.util.List;

public class SelCityActivity extends AppCompatActivity {
    private int anim = R.style.DefaultCityPickerAnimation;
    private DBOpenHelper dbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbOpenHelper = new DBOpenHelper(this);
        List<Weather> alist = dbOpenHelper.getAttentionWeather();
        List<HotCity> hotCityList = new ArrayList<>();
        for(int i=0;i<alist.size();i++){
            Weather weather = alist.get(i);
            HotCity hotCity = new HotCity(weather.getCityname(),"",weather.getCityid());
            hotCityList.add(hotCity);
        }

        CityPicker.from(SelCityActivity.this)
                .enableAnimation(true)
                .setAnimationStyle(anim)
                .setLocatedCity(null)
                .setHotCities(hotCityList)
                .setOnPickListener(new OnPickListener() {
                    @Override
                    public void onPick(int position, City data) {
                        Intent intent = new Intent(SelCityActivity.this, MainActivity.class);
                        intent.putExtra("selcity", data.getName());
                        intent.putExtra("citycode",data.getCode());
                        setResult(RESULT_OK, intent);
                        finish();
                    }

                    @Override
                    public void onCancel(){
                        finish();
                    }

                    @Override
                    public void onLocate() {
                    }
                })
                .show();
    }
}