package com.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.weather.data.Weather;
import com.weather.data.WeatherBean;
import com.weather.utils.DBOpenHelper;
import com.weather.utils.NetUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//主页
public class MainActivity extends AppCompatActivity {

    private TextView pmTv;
    private TextView errorTv;
    private TextView tempTv;
    private TextView weatherTv;
    private TextView windTv;
    private TextView dateTv;
    private View lineView;
    private LinearLayout otherLl;

    private List<String> weekList;
    private Handler handler;
    private String code = "101010100";
    private Button queryBtn;
    private TextView tv_time;
    private EditText et_cityid;

    private DBOpenHelper dbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbOpenHelper = new DBOpenHelper(this);

        et_cityid = findViewById(R.id.et_cityid);
        tv_time = findViewById(R.id.tv_time);
        pmTv = findViewById(R.id.pm_tv);
        errorTv = findViewById(R.id.error_tv);
        tempTv = findViewById(R.id.temp_tv);
        weatherTv = findViewById(R.id.weather_tv);
        windTv = findViewById(R.id.wind_tv);
        dateTv = findViewById(R.id.date_tv);
        lineView = findViewById(R.id.line_view);
        otherLl = findViewById(R.id.other_ll);
        queryBtn = findViewById(R.id.queryBtn);
        queryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cityid=et_cityid.getText().toString();
                if(cityid.equals("")) {
                    //跳转到城市选择页面
                    Intent intent = new Intent(MainActivity.this, SelCityActivity.class);
                    startActivityForResult(intent, 1000);
                }else{
                    code=cityid;
                    getData(code);
                }
            }
        });
        findViewById(R.id.updateBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //调用天气
                if(code.equals("")){
                    Toast.makeText(MainActivity.this,"请输入城市ID",Toast.LENGTH_SHORT).show();
                }else {
                    getData(code);
                }
            }
        });
        findViewById(R.id.attentionBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(code.equals("")){
                    Toast.makeText(MainActivity.this,"请输入城市ID",Toast.LENGTH_SHORT).show();
                }else {
                    //检查是否关注过
                    Weather data = dbOpenHelper.getWeather(code);
                    if(data==null){
                        Toast.makeText(MainActivity.this,"城市ID未存储",Toast.LENGTH_SHORT).show();
                    }else{
                        if(data.getIsattention().equals("y")){
                            Toast.makeText(MainActivity.this,"城市ID已经关注，请勿重复关注",Toast.LENGTH_SHORT).show();
                        }else{
                            boolean flag = dbOpenHelper.updateAttention(code);
                            if(flag){
                                Toast.makeText(MainActivity.this,"城市ID关注成功",Toast.LENGTH_SHORT).show();
                            }else{
                                Toast.makeText(MainActivity.this,"城市ID关注失败",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        });

        initData();
        getData("101010100");
    }

    /**
     * 获取网络数据
     */
    private void getData(final String code) {
        if (!NetUtils.isActive(MainActivity.this)) {
            errorTv.setText("请确认是否有网");
            Toast.makeText(MainActivity.this, "亲，确认您是否有网！", Toast.LENGTH_LONG).show();
            return;
        }

        //开一个子线程进行网络请求  获取服务器json数据
        new Thread(new Runnable() {
            @Override
            public void run() {
                String uri = "http://weather.123.duba.net/static/weather_info/" + code + ".html";
                String result = NetUtils.doGet(uri);
                //list集合中存的今天+未来五天的天气信息
                List<WeatherBean> list = parserJson(result);
                Message message = handler.obtainMessage();
                //集合数据为空时让其检查网络问题
                if (list == null || list.size() == 0) {
                    message.what = 200;
                    message.obj = "请检查网络";
                    handler.sendMessage(message);
                    return;
                }
                message.what = 100;
                message.obj = list;
                handler.sendMessage(message);
            }
        }).start();
    }

    /**
     * 解析json数据
     *
     * @param result
     */
    private List<WeatherBean> parserJson(String result) {
        List<WeatherBean> list = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(result);
            JSONObject weatherInfo = jsonObject.getJSONObject("weatherinfo");
            String updatetime = jsonObject.getString("update_time");
            //保存今天+未来五天的天气数据
            for (int i = 1; i < 7; i++) {
                WeatherBean weatherBean = new WeatherBean();
                if (i == 1) {
                    weatherBean.setCity(weatherInfo.getString("city"));
                    weatherBean.setCityId(weatherInfo.getString("cityid"));
                    weatherBean.setDate_y(weatherInfo.getString("date_y"));
                    weatherBean.setPm("PM:" + weatherInfo.getString("pm") + " " + weatherInfo.getString("pm-level"));
                    weatherBean.setTempCurrent(weatherInfo.getString("temp") + "°");
                    weatherBean.setWindCurrent(weatherInfo.getString("wd") + " " + weatherInfo.getString("ws"));
                    weatherBean.setUpdatetime(updatetime);
                    dbOpenHelper.addWeather(code,weatherInfo.getString("city"),result);
                    queryBtn.setText(weatherInfo.getString("city"));
                }
                weatherBean.setWeek(getWeek(i, weatherInfo.getString("week")));
                weatherBean.setTemp(weatherInfo.getString("temp" + i));
                weatherBean.setWeather(weatherInfo.getString("weather" + i));
                //将每天的天气信息保存到集合中
                list.add(weatherBean);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @param i
     * @param week
     * @return 星期几
     */
    private String getWeek(int i, String week) {
        int index = 0;
        for (int j = 0; j < weekList.size(); j++) {
            if (weekList.get(j).equals(week)) {
                index = j;
                break;
            }
        }
        if (index + i < 8) {
            index = index + i - 1;
        } else {
            index = index + i - 8;
        }
        return weekList.get(index);
    }

    private void initData() {
        //在Android中借助handler类实现从服务器获取数据后更新UI页面
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 200) {
                    errorTv.setText((String) msg.obj);
                }
                if (msg.what == 100) {
                    errorTv.setText("");
                    List<WeatherBean> list = (List<WeatherBean>) msg.obj;
                    pmTv.setText(list.get(0).getPm());
                    tempTv.setText(list.get(0).getTempCurrent());
                    weatherTv.setText(list.get(0).getWeather() + " " + list.get(0).getTemp());
                    windTv.setText(list.get(0).getWindCurrent());
                    dateTv.setText(list.get(0).getDate_y() + " " + list.get(0).getWeek());
                    tv_time.setText(list.get(0).getUpdatetime());
                    if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("优")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.pm1));
                    } else if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("良")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.pm2));
                    } else if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("轻度污染")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.pm3));
                    } else if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("中度")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.pm4));
                    } else if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("重度")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.pm5));
                    } else if (list.get(0).getPm().substring(list.get(0).getPm().lastIndexOf(" ") + 1).equals("严重")) {
                        lineView.setBackgroundColor(getResources().getColor(R.color.black));
                    }
                    //清空水平滚动条的孙子辈视图
                    otherLl.removeAllViews();
                    //将未来五天的天气信息动态设置到水平滚动条中的线性布局中的子视图中
                    for (int i = 1; i < list.size(); i++) {
                        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.weather_item, null);
                        TextView weekItemTv = view.findViewById(R.id.tv_week_item);
                        TextView weatherItemTv = view.findViewById(R.id.tv_weather_item);
                        TextView tempItemTv = view.findViewById(R.id.tv_temp_item);
                        weekItemTv.setText(list.get(i).getWeek());
                        weatherItemTv.setText(list.get(i).getWeather());
                        tempItemTv.setText(list.get(i).getTemp());
                        //动态将item视图添加到otherLl中
                        otherLl.addView(view);
                    }
                }
            }
        };
        weekList = new ArrayList<>();
        weekList.add("星期一");
        weekList.add("星期二");
        weekList.add("星期三");
        weekList.add("星期四");
        weekList.add("星期五");
        weekList.add("星期六");
        weekList.add("星期日");
    }

    //获取返回值
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1000) {
            if (resultCode != RESULT_OK) {
                return;
            }
            if (data != null) {
                queryBtn.setText(data.getStringExtra("selcity"));
                code = data.getStringExtra("citycode");
                //检索数据库中是否存在该城市ID
                Weather dbdata=dbOpenHelper.getWeather(code);
                if(dbdata==null) {
                    //调用api获取天气
                    getData(code);
                }else{
                    List<WeatherBean> list = parserJson(dbdata.getJsondata());
                    Message message = handler.obtainMessage();
                    //集合数据为空时让其检查网络问题
                    if (list == null || list.size() == 0) {
                        message.what = 200;
                        message.obj = "请检查网络";
                        handler.sendMessage(message);
                    }
                    message.what = 100;
                    message.obj = list;
                    handler.sendMessage(message);
                }
            }
        }
    }
}