package com.player.utils;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.player.data.Music;

import java.util.ArrayList;
import java.util.List;

public class DBOpenHelper extends SQLiteOpenHelper {
    /**
     * 声明一个AndroidSDK自带的数据库变量db
     */
    private SQLiteDatabase db;

    /**
     * 写一个这个类的构造函数，参数为上下文context，所谓上下文就是这个类所在包的路径
     */
    public DBOpenHelper(Context context){
        super(context,"db_test",null,1);
        db = getReadableDatabase();
    }

    /**
     * 重写两个必须要重写的方法，因为class DBOpenHelper extends SQLiteOpenHelper
     * 而这两个方法是 abstract 类 SQLiteOpenHelper 中声明的 abstract 方法
     * 所以必须在子类 DBOpenHelper 中重写 abstract 方法
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db){
        //歌曲表
        db.execSQL("CREATE TABLE IF NOT EXISTS musics(" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT," +
                "player TEXT," +
                "time INTEGER," +
                "path TEXT," +
                "url TEXT)");

        initDataBase(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        onCreate(db);
    }

    //预设5首歌曲
    private void initDataBase (SQLiteDatabase db) {
        Music music1 = new Music();
        music1.setMusic_name("belltower");
        music1.setMusic_player("Tea K Pea");
        music1.setMusic_time(140000);
        music1.setMusic_path("https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/gO0sJNBxSHzYZKjNippGA0G6a6PuxgCaBsCCA5IL.mp3?download=1&name=Tea%20K%20Pea%20-%20belltower.mp3");
        ContentValues values = new ContentValues();
        values.put("title",music1.getMusic_name());
        values.put("player",music1.getMusic_player());
        values.put("time",music1.getMusic_time());
        values.put("url","");
        values.put("path",music1.getMusic_path());
        db.insert("musics", null, values);

        Music music2 = new Music();
        music2.setMusic_name("chromaticmetal");
        music2.setMusic_player("Tea K Pea");
        music2.setMusic_time(236000);
        music2.setMusic_path("https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/NgMkoFyw1umUt7ifKgQ8HA97LTyNQWcmaSWxaLWo.mp3?download=1&name=Tea%20K%20Pea%20-%20chromaticmetal.mp3");
        values.put("title",music2.getMusic_name());
        values.put("player",music2.getMusic_player());
        values.put("time",music2.getMusic_time());
        values.put("url","");
        values.put("path",music2.getMusic_path());
        db.insert("musics", null, values);

        Music music3 = new Music();
        music3.setMusic_name("LittleWooden Church");
        music3.setMusic_player("The Trumpeteers");
        music3.setMusic_time(180000);
        music3.setMusic_path("https://files.freemusicarchive.org/storage-freemusicarchive-org/music/WFMU/Voodoo_Suite/blissbloodcom/Voodoo_Suite_-_03_-_Little_Grass_Shack.mp3?download=1&name=Voodoo%20Suite%20-%20Little%20Grass%20Shack.mp3");
        values.put("title",music3.getMusic_name());
        values.put("player",music3.getMusic_player());
        values.put("time",music3.getMusic_time());
        values.put("url","");
        values.put("path",music3.getMusic_path());
        db.insert("musics", null, values);

        Music music4 = new Music();
        music4.setMusic_name("Buck break");
        music4.setMusic_player("ken Hamm");
        music4.setMusic_time(180000);
        music4.setMusic_path("https://files.freemusicarchive.org/storage-freemusicarchive-org/music/Peppermill_Records/Ken_Hamm/Hi_and_Ho_We_Plant_Trees/Ken_Hamm_-_08_-_Buckbreak.mp3?download=1&name=Ken%20Hamm%20-%20Buckbreak.mp3");
        values.put("title",music4.getMusic_name());
        values.put("player",music4.getMusic_player());
        values.put("time",music4.getMusic_time());
        values.put("url","");
        values.put("path",music4.getMusic_path());
        db.insert("musics", null, values);

        Music music5 = new Music();
        music5.setMusic_name("peril");
        music5.setMusic_player("Xylo-Ziko");
        music5.setMusic_time(124000);
        music5.setMusic_path("https://files.freemusicarchive.org/storage-freemusicarchive-org/tracks/walafIDnmIxt8dwZ9pBXkFLDqPSZktvLqJYiMOCP.mp3?download=1&name=Xylo-Ziko%20-%20peril.mp3");
        values.put("title",music5.getMusic_name());
        values.put("player",music5.getMusic_player());
        values.put("time",music5.getMusic_time());
        values.put("url","");
        values.put("path",music5.getMusic_path());
        db.insert("musics", null, values);
    }

    /**
     * 接下来写自定义的增删改查方法
     */
    //将歌曲添加到数据库中
    public boolean addMusic(Music music){
        ContentValues values = new ContentValues();
        values.put("title",music.getMusic_name());
        values.put("player",music.getMusic_player());
        values.put("time",music.getMusic_time());
        values.put("url","");
        values.put("path",music.getMusic_path());
        return db.insert("musics", null, values) > 0;
    }

    //更新歌曲地址
    public boolean updateMusic(int id,String url){
        ContentValues values = new ContentValues();
        values.put("url",url);
        return db.update("musics",values,"_id=?",new String[]{id+""}) > 0;
    }

    //获取所有歌曲
    @SuppressLint("Range")
    public List<Music> getMusics(){
        List<Music> list = new ArrayList<>();
        Cursor cursor = db.query("musics",null,null,null,null,null,null);
        while(cursor.moveToNext()){
            Music music = new Music();
            music.setId(cursor.getInt(cursor.getColumnIndex("_id")));
            music.setMusic_name(cursor.getString(cursor.getColumnIndex("title")));
            music.setMusic_player(cursor.getString(cursor.getColumnIndex("player")));
            music.setMusic_time(cursor.getInt(cursor.getColumnIndex("time")));
            music.setMusic_url(cursor.getString(cursor.getColumnIndex("url")));
            music.setPlaying(false);
            music.setMusic_path(cursor.getString(cursor.getColumnIndex("path")));
            list.add(music);
        }
        return list;
    }

    //获取指定歌曲信息
    @SuppressLint("Range")
    public Music getMusic(int id){
        Music music=null;
        Cursor cursor = db.query("musics",null,"_id="+id,null,null,null,null);
        if(cursor.moveToNext()){
            music = new Music();
            music.setId(cursor.getInt(cursor.getColumnIndex("_id")));
            music.setMusic_name(cursor.getString(cursor.getColumnIndex("title")));
            music.setMusic_player(cursor.getString(cursor.getColumnIndex("player")));
            music.setMusic_time(cursor.getInt(cursor.getColumnIndex("time")));
            music.setMusic_url(cursor.getString(cursor.getColumnIndex("url")));
            music.setPlaying(false);
            music.setMusic_path(cursor.getString(cursor.getColumnIndex("path")));
        }
        return music;
    }
}
