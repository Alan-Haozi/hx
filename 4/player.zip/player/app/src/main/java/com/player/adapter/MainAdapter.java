package com.player.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.player.R;
import com.player.data.Music;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainAdapter extends BaseAdapter {
    private Context context;
    private List<Music> list = new ArrayList<>();

    public MainAdapter(Context context,List<Music> objects){
        super();
        this.context=context;
        this.list = objects;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, null);
            holder = new ViewHolder();
            holder.musicName = convertView.findViewById(R.id.tv_musicname);
            holder.musicPlayer = convertView.findViewById(R.id.tv_musicplayer);
            holder.musicTime = convertView.findViewById(R.id.tv_musictime);
            convertView.setTag(holder);
        }
        Music music = list.get(position);
        holder = (ViewHolder) convertView.getTag();
        holder.musicName.setText(music.getMusic_name());
        holder.musicPlayer.setText(music.getMusic_player());
        holder.musicTime.setText(formatTime(music.getMusic_time()));
        return convertView;
    }

    private String formatTime(int length) {
        Date date = new Date(length);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mm:ss");    //规定固定的格式
        String totaltime = simpleDateFormat.format(date);
        return totaltime;
    }

    class ViewHolder{
        public TextView musicName;
        public TextView musicPlayer;
        public TextView musicTime;
    }
}
