package com.player;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.player.adapter.MainAdapter;
import com.player.data.Music;
import com.player.utils.DBOpenHelper;

import java.util.ArrayList;
import java.util.List;

//主页
public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private List<Music> list = new ArrayList<>();
    private MainAdapter adapter;
    private DBOpenHelper dbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbOpenHelper = new DBOpenHelper(this);
        list=dbOpenHelper.getMusics();
        listView = findViewById(R.id.list_view);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //点击跳转到播放页面
                Intent intent = new Intent(MainActivity.this,PlayActivity.class);
                intent.putExtra("id",list.get(i).getId()+"");
                intent.putExtra("index",i+"");
                startActivity(intent);
            }
        });
        adapter = new MainAdapter(this,list);
        listView.setAdapter(adapter);
    }
}