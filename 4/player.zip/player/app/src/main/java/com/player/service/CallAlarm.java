package com.player.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.player.PlayActivity;
import com.player.utils.DBOpenHelper;

public class CallAlarm extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent)
    {
        String filepath=intent.getStringExtra("downloadFile");
        String curid=intent.getStringExtra("id");
        String curindex=intent.getStringExtra("index");
        //更新数据库
        DBOpenHelper dbOpenHelper = new DBOpenHelper(context);
        dbOpenHelper.updateMusic(Integer.parseInt(curid),filepath);
        //跳转
        Intent i = new Intent(context, PlayActivity.class);
        i.putExtra("id",curid);
        i.putExtra("index",curindex);
        context.startActivity(i);
    }
}
