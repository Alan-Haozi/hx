package com.player.service;

import android.app.IntentService;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

import com.player.R;
import com.player.utils.DBOpenHelper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.core.app.NotificationCompat;

/**
 * 下载服务
 */
public class DownLoadService extends IntentService {
    private final String TAG="LOGCAT";
    private int fileLength, downloadLength;//文件大小
    private Handler handler = new Handler();
    private NotificationCompat.Builder builder;
    private NotificationManager manager;
    private int _notificationID = 1024;
    public DownLoadService() {
        super("DownLoadService");//这就是个name
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    protected void onHandleIntent(Intent intent) {
        try {
            initNotification();

            Bundle bundle = intent.getExtras();
            String downloadUrl = bundle.getString("download_url");
            String curid=bundle.getString("id");
            String curindex=bundle.getString("index");

           // File dirs = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download");//文件保存地址
//            if (!dirs.exists()) {// 检查文件夹是否存在，不存在则创建
//                dirs.mkdir();
//            }

            SimpleDateFormat formatter = new SimpleDateFormat ("yyyyMMddHHmmss");
            Date curDate = new Date(System.currentTimeMillis());
         //   File file = new File(dirs, formatter.format(curDate)+".mp3");//输出文件名
            File file=new File("data/data/com.player/"+formatter.format(curDate)+".mp3");
            if (!file.exists()) {// 检查文件夹是否存在，不存在则创建
                file.createNewFile();
            }

            Log.d(TAG,"下载启动："+downloadUrl+" --to-- "+ file.getPath());
            manager.notify(_notificationID,builder.build());
            // 开始下载
            downloadFile(downloadUrl, file);
            // 下载结束
            builder.setProgress(0,0,false);//移除进度条
            builder.setContentText("下载结束");
            manager.notify(_notificationID,builder.build());

            // 广播下载完成事件，通过广播调起对文件的处理。


            Log.i("MyTag", "onClick: 发送广播");
            Intent sendIntent = new Intent();
            sendIntent.putExtra("downloadFile", file.getPath());
            sendIntent.putExtra("id",curid);
            sendIntent.putExtra("index",curindex);
            sendIntent.setComponent(new ComponentName("com.player","com.player.service.CallAlarm"));
            sendBroadcast(sendIntent);
            Log.d(TAG,"下载结束");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 文件下载
     * @param downloadUrl
     * @param file
     */
    private void downloadFile(String downloadUrl, File file){
        FileOutputStream _outputStream;//文件输出流
        try {
            _outputStream = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "找不到目录！");
            e.printStackTrace();
            return;
        }
        InputStream _inputStream = null;//文件输入流
        try {
            URL url = new URL(downloadUrl);
            HttpURLConnection _downLoadCon = (HttpURLConnection) url.openConnection();
            _downLoadCon.setRequestMethod("GET");
            fileLength = Integer.valueOf(_downLoadCon.getHeaderField("Content-Length"));//文件大小
            _inputStream = _downLoadCon.getInputStream();
            int respondCode = _downLoadCon.getResponseCode();//服务器返回的响应码
            if (respondCode == 200) {
                handler.post(run);//更新下载进度
                byte[] buffer = new byte[1024*8];// 数据块，等下把读取到的数据储存在这个数组，这个东西的大小看需要定，不要太小。
                int len;
                while ((len = _inputStream.read(buffer)) != -1) {
                    _outputStream.write(buffer, 0, len);
                    downloadLength = downloadLength + len;
//                    Log.d(TAG, downloadLength + "/" + fileLength );
                }
            } else {
                Log.d(TAG, "respondCode:" + respondCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {//别忘了关闭流
                if (_outputStream != null) {
                    _outputStream.close();
                }
                if (_inputStream != null) {
                    _inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Runnable run = new Runnable() {
        public void run() {
            int _pec=(int) (downloadLength*100 / fileLength);
            builder.setContentText("下载中……"+_pec+"%");
            builder.setProgress(100, _pec, false);//显示进度条，参数分别是最大值、当前值、是否显示具体进度（false显示具体进度，true就只显示一个滚动色带）
            manager.notify(_notificationID,builder.build());
            handler.postDelayed(run, 1000);
        }
    };

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy");
        handler.removeCallbacks(run);
        super.onDestroy();
    }

    public void initNotification(){
        builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("下载文件").setContentText("下载中……");//图标、标题、内容这三个设置是必须要有的。
        manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }
}
