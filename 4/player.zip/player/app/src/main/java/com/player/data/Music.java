package com.player.data;

//歌曲实体类
public class Music {
    private int id;
    private String music_name;//歌曲名称
    private String music_player;//歌手
    private int music_time;//时长
    private String music_url;//本地路径
    public boolean isPlaying;
    private String music_path;//网络下载路径

    public String getMusic_name() {
        return music_name;
    }

    public void setMusic_name(String music_name) {
        this.music_name = music_name;
    }

    public String getMusic_player() {
        return music_player;
    }

    public void setMusic_player(String music_player) {
        this.music_player = music_player;
    }

    public int getMusic_time() {
        return music_time;
    }

    public void setMusic_time(int music_time) {
        this.music_time = music_time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMusic_url() {
        return music_url;
    }

    public void setMusic_url(String music_url) {
        this.music_url = music_url;
    }

    public boolean isPlaying() {
        return isPlaying;
    }

    public void setPlaying(boolean playing) {
        isPlaying = playing;
    }

    public String getMusic_path() {
        return music_path;
    }

    public void setMusic_path(String music_path) {
        this.music_path = music_path;
    }
}
